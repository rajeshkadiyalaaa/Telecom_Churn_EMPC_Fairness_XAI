"""Independent, non-destructive audit. Run from any directory with audit/.venv/bin/python."""
import ast
import hashlib
import importlib.metadata
import json
import io
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from imblearn.over_sampling import SMOTE

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'audit'
ORIGINAL = ROOT / 'original_submission' if (ROOT / 'original_submission').exists() else ROOT
df = pd.read_csv(ROOT / '01_Data/telco_churn_raw.csv')
tc = pd.to_numeric(df.TotalCharges, errors='coerce')
blank = tc.isna()
result = {'scope': 'Independent verification and diagnostic baseline, not reproduction of claimed CatBoost results',
          'versions': {p: importlib.metadata.version(p) for p in ['numpy','pandas','scipy','scikit-learn','imbalanced-learn']},
          'original_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for folder in ['01_Data','02_Colab_Notebooks','03_Figures_and_Tables','04_Scientific_Report']
                              for p in ((ROOT if folder == '01_Data' else ORIGINAL)/folder).iterdir() if p.is_file()},
          'data': {'shape': list(df.shape), 'unique_ids': df.customerID.nunique(),
                   'duplicates': int(df.duplicated().sum()), 'churn_count': int((df.Churn=='Yes').sum()),
                   'blank_indices': df.index[blank].tolist(), 'blank_tenures': df.loc[blank,'tenure'].tolist(),
                   'blank_churn': df.loc[blank,'Churn'].tolist()}}
url = 'https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv'
try:
    remote = pd.read_csv(io.BytesIO(urllib.request.urlopen(url, timeout=20).read()))
    result['ibm_remote_comparison'] = {'url': url, 'same_values_and_row_order': df.equals(remote)}
except Exception as exc:
    result['ibm_remote_comparison'] = {'url': url, 'error': str(exc)}
literal_matrix = np.array([[1., .246862, .825880], [.246862, 1., .651065], [.825880, .651065, 1.]])
result['literal_step2_matrix_vif'] = np.diag(np.linalg.inv(literal_matrix)).tolist()
df['TotalCharges'] = tc.fillna(0.)
df['Churn_Binary'] = (df.Churn=='Yes').astype(int)
clean = pd.read_csv(ROOT/'01_Data/telco_churn_step1_cleaned.csv')
result['data']['cleaned_matches_recomputation'] = df.equals(clean)
train, test = train_test_split(df, test_size=.2, random_state=42, stratify=df.Churn_Binary)
result['split'] = {'train': len(train), 'test': len(test), 'test_churn': int(test.Churn_Binary.sum())}
result['subgroups'] = {a: test.groupby(a).Churn_Binary.agg(['size','sum','mean']).reset_index().to_dict('records') for a in ['SeniorCitizen','gender']}
nb = json.loads((ORIGINAL/'02_Colab_Notebooks/Step2_Feature_Engineering_and_Preprocessing.ipynb').read_text())
# Execute only the inspected, deterministic feature function from the submitted notebook.
tree = ast.parse(''.join(nb['cells'][3]['source']))
fn = next(n for n in tree.body if isinstance(n,ast.FunctionDef))
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<original feature function>','exec'))
fe = engineer_telecom_features(train)
full_fe = engineer_telecom_features(df)
cols = ['Billing_Overage_Residual','Realized_Monthly_Ratio','Avg_Price_Per_Service','Protection_AddOn_Count','Protection_to_Streaming_Ratio','Contract_Tenure_Stability']
result['feature_statistics_full_data'] = {c: {'min':float(full_fe[c].min()),'max':float(full_fe[c].max()),'mean':float(full_fe[c].mean()),'correlation_with_churn':float(full_fe[c].corr(df.Churn_Binary))} for c in cols}
result['vif'] = {}
for name, columns in [('raw', ['tenure','MonthlyCharges','TotalCharges']),('replacement', ['tenure','MonthlyCharges','Billing_Overage_Residual']),('six_scaled', ['tenure','MonthlyCharges','Billing_Overage_Residual','Realized_Monthly_Ratio','Avg_Price_Per_Service','Contract_Tenure_Stability'])]:
    corr = fe[columns].corr().to_numpy()
    result['vif'][name] = dict(zip(columns, np.diag(np.linalg.inv(corr)).tolist()))
result['step2_remaining_categorical_columns'] = fe.drop(columns=['customerID','Churn','Churn_Binary']).select_dtypes(exclude='number').columns.tolist()
scale_cols = ['tenure','MonthlyCharges','Billing_Overage_Residual','Realized_Monthly_Ratio','Avg_Price_Per_Service','Contract_Tenure_Stability']
fe[scale_cols] = StandardScaler().fit_transform(fe[scale_cols])
try:
    SMOTE(random_state=42).fit_resample(fe.drop(columns=['customerID','Churn','Churn_Binary']),fe.Churn_Binary)
except Exception as e:
    result['reproduced_step3_failure_after_step2'] = f'{type(e).__name__}: {e}'

# A deliberately simple diagnostic model; fixed defaults, no tuning on the old test set.
X = df.drop(columns=['customerID','Churn','Churn_Binary'])
numeric = X.select_dtypes('number').columns.tolist()
categorical = X.select_dtypes(exclude='number').columns.tolist()
pre = ColumnTransformer([('numeric',StandardScaler(),numeric),('category',OneHotEncoder(handle_unknown='ignore',drop='first'),categorical)])
model = make_pipeline(pre,LogisticRegression(max_iter=2000,random_state=42))
model.fit(X.loc[train.index],train.Churn_Binary)
prob = model.predict_proba(X.loc[test.index])[:,1]
result['diagnostic_logistic_regression'] = {'roc_auc':roc_auc_score(test.Churn_Binary,prob),'average_precision':average_precision_score(test.Churn_Binary,prob),'brier':brier_score_loss(test.Churn_Binary,prob),'policies':{}}
for threshold in [.5,11/67]:
    tn,fp,fn,tp = confusion_matrix(test.Churn_Binary,prob>=threshold).ravel()
    result['diagnostic_logistic_regression']['policies'][str(threshold)] = {'TN':int(tn),'FP':int(fp),'FN':int(fn),'TP':int(tp),'assumed_payoff':int(56*tp-11*fp)}
pd.DataFrame({'customerID':test.customerID,'y_true':test.Churn_Binary,'p_diagnostic_lr':prob,'SeniorCitizen':test.SeniorCitizen,'gender':test.gender}).to_csv(OUT/'diagnostic_predictions.csv',index=False)
result['reported_profit_arithmetic'] = {'standard':56*205-11*102,'economic':56*332-11*341,'equal_opportunity':56*(84+247)-11*(59+279),'eo_cost':(56*332-11*341)-(56*(84+247)-11*(59+279))}
(OUT/'verification_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='original_sha256'},indent=2))
