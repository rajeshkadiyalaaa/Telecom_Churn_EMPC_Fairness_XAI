"""Generate corrected figures, tables, research report and abstract from stored experiments."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.calibration import calibration_curve
from churn_study import clean_data, policy_metrics, tpr_gap

ROOT=Path(__file__).resolve().parents[1]
RESULTS=ROOT/'results';FIG=ROOT/'03_Figures_and_Tables';REPORT=ROOT/'04_Scientific_Report'

def markdown_table(df):
    def fmt(x):
        if isinstance(x,(float,np.floating)):return f'{x:.4f}' if abs(x)<10 else f'{x:,.2f}'
        return str(x).replace('|',' / ')
    return '| '+' | '.join(map(str,df.columns))+' |\n| '+' | '.join(['---']*len(df.columns))+' |\n'+'\n'.join('| '+' | '.join(fmt(x) for x in row)+' |' for row in df.itertuples(index=False,name=None))

def main():
    FIG.mkdir(exist_ok=True);REPORT.mkdir(exist_ok=True)
    manifest=json.loads((RESULTS/'manifest.json').read_text())
    assert manifest['status']=='complete','Experiments have not completed'
    assert manifest['source_sha256']==hashlib.sha256((ROOT/'src/churn_study.py').read_bytes()).hexdigest(),'Source changed; rerun the experiment'
    cfg=manifest['config'];seeds=cfg['seeds'];first=seeds[0]
    m=pd.read_csv(RESULTS/'model_metrics.csv');p=pd.read_csv(RESULTS/'policy_metrics.csv');ci=pd.read_csv(RESULTS/'bootstrap_intervals.csv');f=pd.read_csv(RESULTS/'fairness_metrics.csv')
    test=m.query("partition == 'test' and calibration == 'calibrated'")
    summary=test.groupby('model')[['roc_auc','average_precision','brier','scenario_profit']].agg(['mean','min','max'])
    summary.columns=['_'.join(c) for c in summary.columns];summary.reset_index().to_csv(FIG/'model_summary_across_splits.csv',index=False)
    table=test.groupby('model')[['roc_auc','average_precision','brier','scenario_profit']].mean().reset_index()
    table.to_csv(FIG/'model_means.csv',index=False)
    raw=clean_data(pd.read_csv(ROOT/'01_Data/telco_churn_raw.csv'))
    ablations=[]
    for seed in seeds:
        for model in ['catboost_baseline_original','catboost_baseline_engineered','catboost_baseline_unaware']:
            pr=pd.read_csv(RESULTS/f'seed_{seed}'/f'{model}_test_predictions.csv').merge(raw[['customerID','SeniorCitizen','gender']],on='customerID',validate='one_to_one')
            d=pr.p_calibrated.to_numpy()>=11/67
            ablations.append({'seed':seed,'model':model,**policy_metrics(pr.y_true,d),'senior_tpr_gap':tpr_gap(pr.y_true,d,pr.SeniorCitizen)})
    pd.DataFrame(ablations).to_csv(FIG/'feature_and_unawareness_ablations.csv',index=False)
    for filename in ['policy_metrics','fairness_metrics','bootstrap_intervals','economic_sensitivity','feature_correlations']:
        (FIG/f'{filename}.csv').write_bytes((RESULTS/f'{filename}.csv').read_bytes())
    # Explicit group disparity definitions, including undefined zero-selection ratios.
    disparities=[]
    for (seed,policy,attribute),group in f.groupby(['seed','policy','attribute']):
        sr=group.selection_rate
        disparities.append({'seed':seed,'policy':policy,'attribute':attribute,'selection_minmax_ratio':sr.min()/sr.max() if sr.max()>0 else np.nan,'selection_maxmin_gap':sr.max()-sr.min(),'tpr_maxmin_gap':group.recall.max()-group.recall.min(),'fpr_maxmin_gap':group.fpr.max()-group.fpr.min(),'precision_maxmin_gap':group.precision.max()-group.precision.min()})
    pd.DataFrame(disparities).to_csv(FIG/'group_disparities.csv',index=False)
    plt.rcParams.update({'font.size':10,'figure.dpi':130,'axes.spines.top':False,'axes.spines.right':False})
    colors={'standard_0.5':'#64748b','economic_bayes':'#0284c7','validation_profit':'#0f766e','equal_opportunity':'#a855f7'}
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for name,color in colors.items():
        s=p[p.policy==name].set_index('seed').loc[seeds]
        axes[0].plot(range(len(seeds)),s.scenario_profit,'o-',label=name,color=color)
        axes[1].plot(range(len(seeds)),s.senior_tpr_gap.abs()*100,'o-',label=name,color=color)
    for ax in axes:ax.set_xticks(range(len(seeds)),[str(s) for s in seeds]);ax.set_xlabel('Split seed')
    axes[0].set_ylabel('Simulated test profit (assumed currency units)');axes[0].set_title('Economic decisions on held-out cases')
    axes[1].set_ylabel('Absolute senior TPR gap (percentage points)');axes[1].set_title('Fairness constraint may not transfer to test')
    axes[1].axhline(cfg['equal_opportunity_tolerance']*100,color='#dc2626',linestyle='--',label='Validation tolerance')
    axes[0].legend(fontsize=8);axes[1].legend(fontsize=8)
    fig.savefig(FIG/'profit_and_fairness.png');plt.close(fig)
    selections=json.loads((RESULTS/'policy_selections.json').read_text())
    fig,axes=plt.subplots(1,len(seeds),figsize=(12,4),layout='constrained',squeeze=False)
    for ax,choice in zip(axes[0],selections):
        pr=pd.read_csv(RESULTS/f'seed_{choice["seed"]}'/f'{choice["selected_model"]}_test_predictions.csv')
        for column,label in [('p_raw','Raw'),('p_calibrated','Sigmoid calibrated')]:
            observed,predicted=calibration_curve(pr.y_true,pr[column],n_bins=8,strategy='quantile')
            ax.plot(predicted,observed,'o-',label=label)
        ax.plot([0,1],[0,1],'--',color='#94a3b8');ax.set(xlim=(0,1),ylim=(0,1),xlabel='Mean predicted probability',ylabel='Observed churn fraction',title=f'Seed {choice["seed"]}')
        ax.legend(fontsize=8)
    fig.savefig(FIG/'calibration_diagnostics.png');plt.close(fig)
    shap=pd.read_csv(RESULTS/f'seed_{first}'/'shap_global.csv');shap.to_csv(FIG/'shap_global.csv',index=False)
    local=pd.read_csv(RESULTS/f'seed_{first}'/'shap_local.csv');local.to_csv(FIG/'shap_local.csv',index=False)
    fig,ax=plt.subplots(figsize=(9,5),layout='constrained');s=shap.head(12).iloc[::-1]
    ax.barh(s.feature,s.mean_abs_calibrated_logit_shap,color='#0f766e');ax.set_xlabel('Mean absolute SHAP contribution (calibrated logit)');ax.set_title(f'Actual CatBoost baseline TreeSHAP • seed {first}')
    fig.savefig(FIG/'shap_global.png');plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(13,9),layout='constrained')
    for ax,(customer,rows) in zip(axes.ravel(),local.groupby('customerID',sort=False)):
        rows=rows.assign(magnitude=rows.shap_calibrated_logit.abs()).sort_values('magnitude',ascending=False)
        top=rows.head(7);values=top.shap_calibrated_logit.to_list();names=top.feature.to_list()
        values.append(rows.iloc[7:].shap_calibrated_logit.sum());names.append('All other features')
        base=rows.base_calibrated_logit.iloc[0];current=base
        for i,value in enumerate(values):
            ax.barh(i,abs(value),left=min(current,current+value),color='#dc2626' if value>0 else '#0284c7')
            current+=value
        ax.axvline(base,color='#64748b',ls=':',label=f'Base {base:.2f}');ax.axvline(current,color='black',ls='--',label=f'Final {current:.2f}')
        ax.set_yticks(range(len(names)),names);ax.invert_yaxis();ax.set_xlabel('Cumulative calibrated logit')
        ax.set_title(f'{customer} • p={rows.probability.iloc[0]:.3f}, observed y={rows.y_true.iloc[0]}');ax.legend(fontsize=8)
    fig.savefig(FIG/'shap_local_waterfalls.png');plt.close(fig)
    s=p[p.policy.isin(['validation_profit','equal_opportunity'])].pivot(index='seed',columns='policy',values='scenario_profit').loc[seeds]
    eo=p[p.policy=='equal_opportunity'].set_index('seed').loc[seeds]
    failures=int((eo.senior_tpr_gap.abs()>cfg['equal_opportunity_tolerance']).sum())
    choices=pd.DataFrame([{'seed':c['seed'],'selected_model':c['selected_model'],'global_threshold':c['validation_profit_threshold'],'non_senior_threshold':c['equal_opportunity']['0'],'senior_threshold':c['equal_opportunity']['1'],'validation_abs_gap':c['equal_opportunity']['validation_abs_tpr_gap']} for c in selections])
    outcome=pd.DataFrame({'seed':seeds,'unconstrained_profit':s.validation_profit.to_numpy(),'fairness_constrained_profit':s.equal_opportunity.to_numpy(),'profit_difference':(s.equal_opportunity-s.validation_profit).to_numpy(),'test_abs_TPR_gap_pp':eo.senior_tpr_gap.abs().to_numpy()*100})
    outcome=outcome.merge(ci[ci.metric=='paired_profit_difference'][['seed','lower','upper']],on='seed')
    selected_metrics=pd.DataFrame([test[(test.seed==c['seed'])&(test.model==c['selected_model'])].iloc[0] for c in selections])
    auc_min,auc_max=selected_metrics.roc_auc.min(),selected_metrics.roc_auc.max()
    gap_min,gap_max=eo.senior_tpr_gap.abs().min()*100,eo.senior_tpr_gap.abs().max()*100
    delta=s.equal_opportunity-s.validation_profit
    abstract=f'''# Corrected research abstract

## Calibration and economic uncertainty in fairness constrained telecom churn targeting

Predictive performance alone does not establish whether retention decisions yield robust economic and demographic outcomes. We conducted a retrospective reproducible study of the 7,043-record IBM Telco benchmark using three fixed stratified splits. Eleven configurations per split compared logistic regression, random forest, and CatBoost under no resampling, class weighting, and random oversampling, with additional feature and demographic-exclusion ablations. Model fitting, sigmoid calibration, validation-based policy selection, and testing used disjoint partitions. Campaign economics were scenario assumptions rather than observed intervention outcomes. The validation-selected models achieved test ROC-AUC values of {auc_min:.3f}–{auc_max:.3f}. Senior equal-opportunity policies satisfied a five-percentage-point validation tolerance, but their test absolute recall gaps were {gap_min:.2f}–{gap_max:.2f} percentage points, exceeding the tolerance in {failures} of {len(seeds)} splits. Relative to unconstrained validation-selected thresholds, simulated test profit differences ranged from {delta.min():+.0f} to {delta.max():+.0f} assumed currency units. Paired conditional bootstrap intervals and nine economic scenarios quantified sensitivity. Genuine TreeSHAP explanations were computed for a fixed CatBoost comparator, with calibrated-logit additivity verified numerically. These results show that validation fairness constraints may not transfer to held-out cases and that the measured economic trade-off depends on the split and assumptions. This single-benchmark analysis does not establish causal retention benefits, population fairness, or methodological novelty.
'''
    (REPORT/'Corrected_Abstract.md').write_text(abstract)
    split=pd.read_csv(RESULTS/f'seed_{first}'/'split_ids.csv').groupby('partition').size()
    shapcheck=json.loads((RESULTS/f'seed_{first}'/'shap_validation.json').read_text())
    text=f'''# Corrected telecom churn research report

## Assessment and contribution

This report supersedes the original submission. All numerical results below come from executed code and saved predictions. The original claims of a six-model benchmark, measured near-perfect fairness at a $23 cost, and hand-authored SHAP explanations have been withdrawn. Original artifacts remain in `original_submission/`; the evidence audit is in `audit/AUDIT_REPORT.md`.

The corrected study examines whether calibration and validation-selected economic/fairness decisions remain stable on held-out customers. Its strongest finding is a limitation: the senior equal-opportunity target failed to transfer to test data in {failures} of {len(seeds)} splits. The selected model differed across splits. This is an empirical benchmark contribution, not a demonstrated novel algorithm or a completed journal-ready generalization claim.

## Data and evaluation design

The supplied dataset contains 7,043 distinct customer IDs and 1,869 churn labels. Eleven whitespace cumulative-charge entries occur at zero tenure. We use conditional zero imputation plus a missingness indicator; unexpected nonnumeric values cause a failure. This convention is not a proof of unobserved billing history. ID and target columns are excluded from all predictors.

Seeds {seeds} each split fitting, calibration, validation, and testing into approximately 45%, 15%, 20%, and 20%. For seed {first}, exact sizes are {int(split['fit'])}, {int(split['calibration'])}, {int(split['validation'])}, and {int(split['test'])}, respectively. All partitions are churn-stratified and disjoint within a repeat. Repeats overlap and are not independent datasets. This benchmark was already inspected before the correction; these results are retrospective internal validation, not a prospective untouched-data claim.

There are 11 configurations per split, 33 fits total. Logistic regression, random forest, and CatBoost each use baseline, balanced class weighting, and random oversampling. Two further CatBoost fits add domain features or exclude SeniorCitizen and gender. Random oversampling duplicates fitting rows and avoids fractional categorical customers. The original claimed SMOTE/SMOTE-ENN and neural-network experiments are not part of this corrected study. Hyperparameters are fixed in source and documented in PROTOCOL.md; there is no test-driven tuning.

Standardization and one-hot encoding for logistic regression/random forest are fit only on fitting data; CatBoost handles categories natively. A regularized logistic calibrator is fitted to base-model logits/margins on separate unresampled calibration rows. We measure calibration rather than assert it is perfect. Each repeat selects the primary model by calibrated validation profit at the analytic economic threshold. The two feature ablations do not participate in that selection.

## Model results

The following are descriptive means across three test splits; they are not confidence intervals and do not establish significant superiority. Scenario profit in this table uses the fixed economic threshold 11/67. AP means average precision, not trapezoidal PR area.

{markdown_table(table)}

The full mean/min/max table and raw/calibrated metrics are available in `03_Figures_and_Tables/model_summary_across_splits.csv` and `results/model_metrics.csv`. Differences between configurations must be interpreted against retraining and test-case uncertainty. Ranking by these test means must not be confused with the validation-selected policy models.

![Calibration diagnostics](../03_Figures_and_Tables/calibration_diagnostics.png)

Calibration plots use quantile bins and are descriptive. A visually improved plot or lower Brier score does not certify calibration for every subgroup or under future distribution shift.

## Economic assumptions and fairness policy

Assume customer value=200, offer cost=10, contact cost=1 and acceptance probability=0.3, all in assumed currency units. Selected observed churners contribute 56 units and selected observed non-churners cost 11 units. Thus the analytic break-even probability is 11/67. These are simulated payoffs under a stylized campaign model, not realized profit or observed causal uplift.

For each selected model, validation chooses a global profit-maximizing threshold and a pair of senior/non-senior thresholds maximizing validation profit with absolute TPR gap at most 0.05. Tied scores are kept together and contact-none is included. The fairness objective is equal opportunity for offer allocation among observed churners. It is not a claim that all fairness definitions are simultaneously satisfied.

{markdown_table(choices)}

## Held-out policy outcomes

Profit difference below means fairness-constrained minus unconstrained validation-selected policy. A positive difference is a measured test advantage under the assumptions, not a guaranteed negative cost of fairness. The lower/upper bounds are paired 95% percentile bootstrap intervals for that difference.

{markdown_table(outcome)}

The validation tolerance was exceeded in {failures}/{len(seeds)} test splits. It must not be reported as a guaranteed test-fairness constraint. Finite subgroup samples and distribution differences can make a validation solution fail to transfer. The data also do not support the original claim of a universal $23 fairness penalty. Small positive or negative profit differences do not establish practical benefit without uncertainty and economic context.

![Profit and fairness across splits](../03_Figures_and_Tables/profit_and_fairness.png)

Full policy tables include standard 0.5, analytic threshold, validation profit, equal opportunity, contact all, and contact none. Group tables cover senior status, gender, and their intersections; they derive from the actual test customer IDs. Undefined precision for zero selected cases is left missing. Selection-rate min/max ratios and max–min error gaps are provided as diagnostics, not legal compliance determinations.

## Uncertainty and sensitivity

We use {cfg['bootstrap_replicates']} paired resamples stratified jointly by churn, senior status and gender for each split. Intervals condition on the fitted model, selected policy, and empirical group counts. They do not incorporate the entire training/selection procedure or uncertain economics. Three retraining repeats show sensitivity but are insufficient for claims of independent statistical significance. No t-test over correlated folds is used.

Nine economic scenarios cross CLV in 100/200/400 with acceptance in 0.1/0.3/0.5; offer/contact costs remain fixed. In each scenario thresholds are reselected on validation data and evaluated on test data. See `economic_sensitivity.csv`. A separate empirical EMPC score integrates maximum score-threshold profit under Beta(6,14), including no contact. Test-set EMPC is labeled an oracle descriptive metric; no test-optimal threshold is used as a deployed test policy.

Feature and demographic-exclusion ablations are in `feature_and_unawareness_ablations.csv`. They compare actual fitted CatBoost models at the same analytic threshold. Added features are predictive hypotheses, not proven orthogonal transformations or causal billing mechanisms. Removing demographic columns is not assumed to remove proxies. Neither ablation warrants a causal claim.

## Genuine model explanations

We explain the unweighted original-feature CatBoost comparator on seed {first}, independently of which model wins policy selection. Native CatBoost TreeSHAP supplies genuine feature contributions and the base value from training tree path statistics. The base is not the logit of test prevalence.

Sigmoid calibration is affine in logit space: calibrated logit = a × raw margin + b. Accordingly, each contribution is multiplied by a and the base is transformed by a × base + b. This preserves Shapley additivity for the same explanation game. Maximum raw-margin reconstruction error is {shapcheck['raw_additivity_max_error']:.3g}; maximum calibrated-probability reconstruction error is {shapcheck['calibrated_probability_max_error']:.3g}.

![Global model attributions](../03_Figures_and_Tables/shap_global.png)

![Actual customer explanations](../03_Figures_and_Tables/shap_local_waterfalls.png)

Four real held-out customer IDs were selected by predicted-risk order without selecting their observed labels. Their feature values and contributions are exported. These plots explain predictions; they do not establish that changing a contract, payment method, or service will retain a customer. No 82% mediation claim, invented customer narrative, or untested prescription is retained.

## Research limitations and next academic steps

This remains one small, previously inspected public benchmark. There is no verified longitudinal feature cutoff, external dataset, retention experiment, actual acceptance data, or observed campaign economics. Three splits and fixed model budgets are a limited robustness study. Calibration could be compared with additional methods using development-only selection. Missing-charge sensitivity, more repeats, independent external data, and broader cost scenarios would strengthen the study.

A provisional research question is: how stable is the simulated economic cost of demographic fairness after calibration and across splits and economic assumptions? Do not claim that combining churn prediction, economics, fairness, and SHAP is itself novel. A systematic primary-paper matrix is still needed. If seeking publication, position this as a reproducible empirical robustness study and verify the contribution against the intended venue's literature. Publication readiness and acceptance are not guaranteed.

The student should be able to explain every transformation, split, threshold, and figure and trace every reported number back to saved predictions. Disclose AI assistance according to institutional/venue policy and document any correction of previously shared results.

## References and implementation sources

- Höppner et al., Profit Driven Decision Trees for Churn Prediction: https://arxiv.org/abs/1712.08101 — profit-based modeling and empirical maximum-profit definitions.
- Hardt, Price and Srebro, Equality of Opportunity in Supervised Learning: https://arxiv.org/abs/1610.02413 — group-aware post-processing framework; our deterministic threshold search is explicitly specified rather than claimed as a full replication of their algorithm.
- Chouldechova, Fair prediction with disparate impact: https://arxiv.org/abs/1703.00056 — conditional fairness incompatibilities, not proof of this dataset's mechanism.
- CatBoost TreeSHAP documentation: https://catboost.ai/docs/en/concepts/shap-values — actual contribution computation and additive output convention.
- Scikit-learn calibration documentation: https://scikit-learn.org/stable/modules/calibration.html — disjoint calibration and model-fitting data.
- Rahman, Janssens and Bogaert author repository: https://github.com/ShimantoRahman/churn-preprocessing — prior work using fairness techniques in profit-driven churn preprocessing; compare its objective carefully with demographic equal opportunity.

## Reproducibility

Run the commands in README.md. `results/manifest.json` records the data hash, executed source hash, exact configuration, Python/package versions, and completion state. Each seed folder contains split IDs, all model/calibrator objects, all validation/test predictions, frozen policy choices, and selected-policy test decisions. All tables and figures in this report are generated by `src/build_report.py`. `src/validate_results.py` reconciles exports, checks model replay, confirms split isolation, and verifies SHAP reconstruction.
'''
    (REPORT/'Corrected_Research_Report.md').write_text(text)
    (REPORT/'README.md').write_text('The corrected report and abstract in this folder supersede all Word reports archived under original_submission/04_Scientific_Report. No original numerical claim has been retained without new computation.\n')
    print('Generated corrected report, abstract, tables and four figures.')

if __name__=='__main__':main()
