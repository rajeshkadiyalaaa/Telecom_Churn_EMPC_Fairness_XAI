# Telecom churn research study

This corrected project trains actual models, saves customer-level predictions, selects policies on validation data, and generates its report from measured results. The original submission contained unsupported benchmark, fairness, and SHAP claims. Its notebooks, workbooks, figures, and Word reports are preserved under `original_submission/` and are **superseded, not valid research results**. See `audit/AUDIT_REPORT.md` for the original findings.

## Read the corrected results

- [Corrected research report](04_Scientific_Report/Corrected_Research_Report.md)
- [Corrected abstract](04_Scientific_Report/Corrected_Abstract.md)
- [Executed reproduction notebook](02_Colab_Notebooks/Reproduce_Corrected_Study.ipynb)
- [Protocol and limitations](PROTOCOL.md)
- [Computed tables and figures](03_Figures_and_Tables/)
- [Raw experiment outputs and saved models](results/)

## Reproduce

Tested with Python 3.14.6 on macOS. The exact tested package versions are in `results/manifest.json` and `requirements-lock.txt`; other Python/platform combinations have not been verified.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-lock.txt
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python src/churn_study.py
.venv/bin/python src/build_report.py
.venv/bin/python src/validate_results.py
```

The existing local audit environment can also run these commands using `audit/.venv/bin/python`. No Google Drive mount, credentials, or data download is needed. The provided raw CSV is the source. Configure the experiment in `config/study.json`; changing the configuration requires rebuilding the outputs and report. Run from any directory using absolute script paths; output paths default to this project.

The notebook displays the executed study and validates its provenance. Set its `REBUILD` flag to `True` to train and regenerate all outputs inside the notebook. Its default review mode reads the measured outputs and explicitly says it is doing so.

## What is implemented

Three fixed random splits; 11 configurations per split: logistic regression, random forest, and CatBoost under baseline, class weighting, and random oversampling, plus two CatBoost feature/demographic ablations. Separate fitting, calibration, validation, and test partitions. Real sigmoid calibration. Six retention policies, validation-constrained senior equal opportunity, gender and intersectional audits, paired conditional bootstrap intervals, nine economic scenarios, empirical EMPC as a separately labeled oracle ranking metric, and genuine CatBoost TreeSHAP with numerical additivity checks.

XGBoost, LightGBM, focal-loss MLP, SMOTE and SMOTE-ENN are **not claimed as completed experiments** in the corrected study. Random oversampling is used as a valid mixed-data comparator that does not create fractional categorical customers. The supplied data is not an intervention trial; all profits are scenario calculations in assumed currency units, and SHAP is not causal evidence. This is a retrospective single-benchmark study, not a demonstrated production system or a guaranteed publishable novel method.

Do not load joblib model files from untrusted sources. The models here were generated locally by the supplied script.

## Publication preparation

The completed ten-split publication extension, Word manuscript, cover letter, verified reproducibility archive, and author-completion checklist are in [publication/README.md](publication/README.md). Publication results supersede the three-split descriptive report for manuscript purposes. Administrative placeholders remain intentional; nothing has been submitted.
