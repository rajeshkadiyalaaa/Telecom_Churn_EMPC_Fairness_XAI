# Publication package

Prepared 18 October 2026. This is an author-review package, not a submitted or accepted paper. The manuscript reports the completed ten-split experiment under publication/experiments. Earlier three-split reports remain historical outputs and should not be submitted as the final manuscript.

## Files

- Manuscript.docx: editable journal manuscript, measured tables and two figures, numbered references, author placeholders.
- Cover_Letter.docx: editable covering letter with explicitly pending author confirmations.
- Manuscript.md: editable text source; table/figure tokens are expanded by build_documents.py.
- Reproducibility_Supplement.zip: code, configuration, result evidence and instructions; excludes fitted binary estimators, private administrative material, and the superseded student submission.
- LITERATURE_REVIEW.md: focused evidence map and bounded contribution.
- AUTHOR_COMPLETION.md: remaining author-owned information and confirmations.
- figures/: standalone 600-dpi PNG and vector EPS files.
- split_summary.csv, model_summary.csv, calibration_summary.csv, economics_summary.csv: generated tables.
- experiments/validation.json: successful replay check, 220 prediction artifacts and 180 group reconciliations.

## Proposed venue

SN Computer Science is the proposed target for this applied machine-learning evaluation. Its broad computing scope makes it plausible, but the single benchmark and limited methodological novelty remain acceptance risks. The paper is positioned as a transparent empirical study, not a new state-of-the-art algorithm.

Choose the subscription route to avoid an APC. The official page states that no APC applies to that route; open access is optional and charged. Verify the terms at submission, especially any funder requirements. No acceptance or fee waiver is promised.

Sources checked 18 October 2026:
- Publishing routes and charges: https://link.springer.com/journal/42979/how-to-publish-with-us
- Scope: https://link.springer.com/journal/42979/aims-and-scope
- Author instructions: https://link.springer.com/journal/42979/submission-guidelines

The manuscript uses an editable Word file, a structured abstract within 150–250 words, six keywords, numbered citations, and separate declarations. Author information remains to be completed. The journal uses single-blind review. Before upload, confirm the current submission portal requirements and remove every administrative placeholder.

## Reproduce locally

From the project root:

```sh
python -m venv .venv
.venv/bin/python -m pip install -r requirements-lock.txt
.venv/bin/python -m unittest discover -s tests
.venv/bin/python src/churn_study.py --config publication/study_10_splits.json --output publication/experiments
.venv/bin/python src/validate_results.py --output publication/experiments
.venv/bin/python publication/analyze_publication.py
```

The recorded environment is in experiments/manifest.json. Exact bitwise results across hardware or versions are not guaranteed; source and input hashes permit provenance checks. analyze_publication.py rebuilds the publication tables and plots from exported results. prepare_text.py rebuilds narrative source from verified metadata; it contains fixed measured prose, which must be reviewed if experiments change. build_documents.py builds Word files and requires python-docx. Re-render Word files after edits.

## Research status

Execution, internal consistency checks, manuscript drafting, reference checks, figure production and publication packaging are complete. External validation, actual campaign economics, and author declarations are not supplied. Those limitations are disclosed rather than filled with invented claims. Strengthening the research with another independent dataset or intervention evidence would require a new study extension; the present package does not claim those experiments.
