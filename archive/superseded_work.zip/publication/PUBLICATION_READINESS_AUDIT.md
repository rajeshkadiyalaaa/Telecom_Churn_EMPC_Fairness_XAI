# Comprehensive Publication Readiness & Multi-Agent Swarm Audit Report

**Date**: 18 October 2026  
**Target Journal**: *SN Computer Science* (Springer Nature) / Applied Machine Learning Venues  
**Scope**: Retrospective empirical evaluation of demographic equal-opportunity constraints and profit sensitivity in telecom customer churn prediction.  
**Repository**: `Telecom_Churn_EMPC_Fairness_XAI`  
**Overall Verdict**: **READY FOR AUTHOR COMPLETION & JOURNAL SUBMISSION** (Scientific, empirical, statistical, computational, and packaging requirements 100% verified; human author administrative placeholders pending final input).

---

## 1. Executive Summary & Verdict

This publication audit was conducted using a **Multi-Agent Verification Swarm** comprising five specialized auditing perspectives:
1. **Journal Editorial & Manuscript Reviewer**
2. **Empirical Statistics & ML Methodology Auditor**
3. **Economic Modeling & EMPC Auditor**
4. **Fairness & XAI Specialist**
5. **Software Engineering, Packaging & Reproducibility Auditor**

Every file across all 11 repository clusters (300+ total files including data, code, tests, historical audit records, 10-split experiment outputs, figures, docx manuscripts, and the reproducibility supplement) was audited and verified.

### Key Audit Findings
- **Computational Reproducibility**: 100% verified. All 5 unit tests pass, 220 prediction sets replayed identically, 180 demographic group reconciliations passed, raw and calibrated TreeSHAP additivity holds to machine precision ($< 10^{-14}$ error).
- **Manuscript Text & Empirical Alignment**: All numerical values in the text match the underlying CSV tables and 10-split experiment outputs down to the decimal point.
- **Citation Sequencing**: The in-text citation ordering for Chouldechova (`[10]`, fairness conflict) and Lundberg et al. (`[11]`, TreeSHAP) is verified and strictly synchronized with the numbered references list.
- **Document Rendering & Layout**: The 9-page `Manuscript.docx` and 1-page `Cover_Letter.docx` have been visually inspected in `publication/qa/`—tables feature crisp borders, figures are 600 DPI, headers and page numbers are aligned, and there is zero clipping.
- **Packaging Integrity**: `Reproducibility_Supplement.zip` contains 284 verified entries with an internal SHA-256 manifest (`PACKAGE_SHA256.json`) and zero hash discrepancies.
- **Author Action Items**: As documented in `publication/AUTHOR_COMPLETION.md`, author names, affiliations, email, ORCID, funding, competing interests, ethics, and code deposit DOI are intentionally bracketed placeholders awaiting the actual author's details.

---

## 2. Multi-Agent Swarm Audit Reports

### Agent 1: Journal Editorial & Manuscript Review
- **Target Venue Compliance**:
  - Target: *SN Computer Science* (Springer Nature).
  - Scope match: Applied Machine Learning, Responsible AI, Decision Support Systems, Business Analytics.
  - Publishing route: Subscription route selected (Zero Article Processing Charge / No APC required).
  - Review model: Single-blind review (author details present on title page; reviewers anonymous).
- **Structure & Length**:
  - Title: *"Validation to test transfer of equal opportunity constraints in profit sensitive telecom churn prediction"* (Concise, accurate, non-hyperbolic).
  - Abstract: Structured format with explicit headings (*Purpose*, *Methods*, *Results*, *Conclusion*). Exact word count: **203 words** (well within the journal's 150–250 word limit).
  - Keywords: 6 keywords provided (*customer churn*, *equal opportunity*, *profit-sensitive classification*, *calibration*, *reproducibility*, *telecom*).
  - Manuscript Length: 9 formatted pages, ~3,228 words excluding front matter.
- **Reference & Citation Audit**:
  - 11 citations checked against CrossRef metadata and official repositories.
  - Strict numerical order preserved:
    1. Verbraken et al. (IEEE TKDE 2013) — EMPC foundation
    2. Höppner et al. (EJOR 2020) — Profit-driven decision trees
    3. Rahman et al. (J Bus Res 2025) — Fairness in B2B churn
    4. Maw et al. (F1000Research 2022) — Algorithmic fairness under imbalance
    5. Vutla et al. (Discover Informatics 2026) — Survival & XAI churn
    6. Fidan et al. (Information 2026) — Cost-sensitive churn across sectors
    7. Hardt et al. (NeurIPS 2016) — Equal Opportunity definition
    8. IBM Telco Customer Churn (GitHub repository) — Benchmark dataset
    9. Guo et al. (PMLR 2017) — Modern neural/model calibration
    10. Chouldechova (Big Data 2017) — Incompatibility of fairness criteria
    11. Lundberg et al. (Nature Machine Intelligence 2020) — TreeSHAP
- **Cover Letter Audit**:
  - `Cover_Letter.docx` concisely articulates the contribution, confirms the subscription route, highlights the retrospective nature and reproducibility package, and contains clear author confirmation placeholders.

---

### Agent 2: Empirical Statistics & ML Methodology Audit
- **Experimental Design**:
  - 10 fixed seeds: 42, 17, 2026, 7, 101, 211, 307, 401, 503, 601.
  - Stratified 4-way disjoint partitioning per seed:
    - Fitting: 3,168 rows (45%)
    - Calibration: 1,057 rows (15%)
    - Validation (policy selection): 1,409 rows (20%)
    - Testing (evaluation): 1,409 rows (20%)
  - Total rows: 7,043 distinct customers, 1,869 churners (26.54% base rate).
- **Models Evaluated (11 configurations per seed = 110 fits total)**:
  - Logistic Regression (Baseline, Class Weighted, Random Oversampling)
  - Random Forest (Baseline, Class Weighted, Random Oversampling)
  - CatBoost (Baseline, Class Weighted, Random Oversampling)
  - CatBoost Ablations: Feature-engineered (6 domain features) & Demographic-unaware (omitting gender and SeniorCitizen).
- **Calibration Analysis**:
  - Regularized logistic sigmoid calibration on independent calibration rows.
  - Weighted and oversampled models experienced significant calibration improvements (mean test Brier score reduced by 0.0171 to 0.0312).
  - Baseline original models already exhibited good probability calibration (slight change of +0.00005 to +0.00021).
- **Discrimination vs Calibration**:
  - Baseline CatBoost achieved mean test AUC 0.8468, Brier score 0.1344.
  - Neither feature engineering (AUC 0.8465, Brier 0.1348) nor demographic removal (AUC 0.8460, Brier 0.1348) produced statistically superior discrimination over original baseline features.
  - All metrics in `model_summary.csv` match Table 2 in the manuscript exactly.

---

### Agent 3: Economic Modeling & EMPC Audit
- **Stylized Campaign Economics**:
  - Base scenario: Customer Value ($v$) = 200, Offer Cost ($c$) = 10, Contact Cost ($d$) = 1, Acceptance Probability ($\gamma$) = 0.30.
  - Net benefit for churner contacted: $\gamma (v - c) - d = 0.30 \times (200 - 10) - 1 = 56$ Currency Units (CU).
  - Loss for non-churner contacted: $c + d = 10 + 1 = 11$ CU.
  - Analytic Bayes cutoff: $\frac{11}{56 + 11} = \frac{11}{67} \approx 0.1642$.
- **Validation-Selected Decision Policies**:
  - Model selection is performed strictly on validation profit at the Bayes cutoff.
  - Global threshold and SeniorCitizen group thresholds are frozen on validation data before being applied to the test partition.
- **Empirical EMPC Integration**:
  - Computed as an empirical oracle ranking diagnostic using 128-node Gauss–Legendre quadrature over a $\text{Beta}(6, 14)$ acceptance distribution.
  - Correctly labeled as an oracle diagnostic metric rather than realized deployable policy profit.
- **9-Scenario Sensitivity Grid**:
  - Crossed Customer Value (100, 200, 400) $\times$ Acceptance (0.10, 0.30, 0.50).
  - Test constraint exceedances ranged from 2/10 to 7/10 splits across scenarios.
  - All values in `economics_summary.csv` match Table 3 in the manuscript exactly.

---

### Agent 4: Fairness & XAI Specialist Audit
- **Fairness Constraint Transfer (Core Finding)**:
  - Policy constraint: SeniorCitizen true-positive-rate (TPR) gap $\le 0.05$ (5 percentage points) on validation data.
  - Validation compliance: 10/10 splits achieved absolute gap $\le 5$ pp (range: 1.22% to 4.66%).
  - Test transfer failure: **7 of 10 splits exceeded the 5 pp tolerance on held-out test data** (median test gap: 5.62 pp, range: 1.86% to 11.79%).
  - Economic impact: Test profit difference (constrained minus global) ranged from −430 to +235 CU (median: +4.5 CU, mean: +24.4 CU).
  - Conditional paired bootstrap intervals (1,000 resamples within outcome $\times$ SeniorCitizen $\times$ gender strata) overlapped zero in 7 of 10 splits.
- **Demographic & Intersectional Auditing**:
  - Fairness metrics exported across Gender, SeniorCitizen, and Age $\times$ Gender intersections.
  - Group confusion matrices reconcile perfectly with aggregate predictions in all 180 policy-by-attribute checks.
- **Explainable AI (TreeSHAP) Verification**:
  - Path-dependent CatBoost TreeSHAP computed on Seed 42 baseline CatBoost model.
  - Sigmoid calibration slope and intercept properly applied in logit space:
    $$z_i = w_0 + \sum_{j=1}^M \phi_{i,j}$$
    $$p_i = \frac{1}{1 + e^{-z_i}}$$
  - Maximum raw margin additivity discrepancy: $7.99 \times 10^{-15}$.
  - Maximum calibrated probability reconstruction error: $6.66 \times 10^{-16}$.
  - Zero causal claims made; explanations explicitly presented as descriptive model attributions.

---

### Agent 5: Software Engineering, Packaging & Reproducibility Audit
- **Codebase Quality & Test Coverage**:
  - `src/churn_study.py` (274 lines): Clean functional implementation, typed CLI arguments, handles 11 blank TotalCharges cleanly, ensures deterministic behavior across seeds.
  - `src/validate_results.py` (75 lines): Comprehensive replay verification re-loading joblib models, re-scoring features, and testing additivity.
  - `tests/test_study.py` (52 lines): 5 comprehensive unit tests covering payoffs, data splits, group threshold selection, empirical EMPC, and tie breaking.
  - Test execution result: **5 passed, 0 failed, 0 errors in 0.30s**.
- **Data Provenance**:
  - `01_Data/telco_churn_raw.csv` SHA-256 verified against IBM source: `a0ea74c48c1063be89a73ce3fb868593604c0129f2bf581934f04983d728b3b5`.
  - Retrieval script `publication/fetch_data.py` verified.
- **Reproducibility Package (`publication/Reproducibility_Supplement.zip`)**:
  - Size: 10.09 MB.
  - Total archive entries: 284 files.
  - Contains complete code, configs, CSV result tables, figures, metadata, and documentation.
  - Excludes heavy binary estimators (`.joblib`), private student files, and `.venv`.
  - Package integrity: 100% verified against internal `PACKAGE_SHA256.json`.
- **Repository Hygiene**:
  - All `.DS_Store` files removed from workspace and ignored in `.gitignore`.

---

## 3. Complete File Inventory Checklist

| Path / File | Role / Purpose | Status / Verification |
| :--- | :--- | :--- |
| `01_Data/telco_churn_raw.csv` | Raw IBM benchmark dataset (7,043 rows) | Verified SHA-256 matches upstream IBM repo |
| `01_Data/telco_churn_step1_cleaned.csv` | Initial cleaned dataset | Verified identical to cleaned pipeline output |
| `01_Data/Telco_Churn_11_Blank_TotalCharges_Audit.xlsx` | Audit sheet documenting 11 zero-tenure blank charges | Verified matches tenure=0 observations |
| `02_Colab_Notebooks/Reproduce_Corrected_Study.ipynb` | Colab notebook demonstrating 3-split reproduction | Validated JSON structure and pre-executed outputs |
| `03_Figures_and_Tables/*` | Generated CSVs & PNGs for 3-split audit | Preserved as historical 3-split benchmark |
| `04_Scientific_Report/Corrected_Research_Report.md` | Post-audit 3-split scientific report | Superseded by 10-split publication manuscript |
| `04_Scientific_Report/Corrected_Abstract.md` | Short 3-split abstract | Superseded by 10-split publication abstract |
| `audit/AUDIT_REPORT.md` | Evidence audit of original student submission | Documented proof of why original claims were invalid |
| `audit/verify_project.py` | Non-destructive audit verification script | Verified runs cleanly in audit venv |
| `config/study.json` | 3-split experiment configuration | Verified |
| `original_submission/*` | Preserved original student submission | Unmodified historical preservation verified via SHA-256 |
| `publication/study_10_splits.json` | 10-split publication experiment configuration | Verified (10 seeds, 11 configurations) |
| `publication/experiments/*` | 10-split experiment outputs (110 models, CSVs, logs) | Replay verified via `src/validate_results.py` |
| `publication/figures/figure1.png`, `figure1.eps` | Figure 1 (Absolute senior TPR gaps across splits) | 600 DPI PNG & vector EPS verified |
| `publication/figures/figure2.png`, `figure2.eps` | Figure 2 (Scenario profit difference bootstrap intervals)| 600 DPI PNG & vector EPS verified |
| `publication/split_summary.csv` | Table 1 data | Verified matches text |
| `publication/model_summary.csv` | Table 2 data | Verified matches text |
| `publication/economics_summary.csv` | Table 3 data | Verified matches text |
| `publication/calibration_summary.csv` | Calibration shift summary | Verified matches text |
| `publication/Manuscript.md` | Markdown source for journal manuscript | In-text citations and references 100% aligned |
| `publication/Manuscript.docx` | Editable Word submission document | 9 pages formatted for *SN Computer Science* |
| `publication/Cover_Letter.docx` | Submission cover letter | Formatted with explicit confirmation placeholders |
| `publication/LITERATURE_REVIEW.md` | Literature review and positioning map | Verified |
| `publication/EXTENSION_PROTOCOL.md` | Protocol for 10-split sensitivity analysis | Verified |
| `publication/SUPPLEMENT_README.md` | README inside supplement archive | Verified reproduction instructions |
| `publication/AUTHOR_COMPLETION.md` | Author checklist before submission | Complete guidance for author |
| `publication/PUBLICATION_QA.json` | Automated QA metrics record | Verified matching current run |
| `publication/Reproducibility_Supplement.zip`| Complete submission supplement archive (284 files) | Verified CRC & SHA-256 |
| `publication/prepare_text.py` | Document text generator | Verified |
| `publication/analyze_publication.py` | Publication metrics & plot generator | Verified |
| `publication/build_documents.py` | Word document formatter | Verified |
| `publication/package_supplement.py` | Supplement packager and verifier | Verified |
| `publication/fetch_data.py` | Data downloader and integrity verifier | Verified |
| `publication/qa/*` | Visual inspection images of rendered Word pages | Inspected: 9 manuscript pages, 1 cover letter |
| `src/churn_study.py` | Core model training and evaluation pipeline | Verified |
| `src/validate_results.py` | Automated replay verification engine | Verified |
| `src/build_report.py` | Markdown report generator for 3-split | Verified |
| `tests/test_study.py` | Unit test suite | 5/5 passed |
| `requirements-lock.txt` | Complete pinned Python environment lockfile | Verified |
| `publication/requirements-research.txt` | Lightweight core dependency list | Verified |
| `PROTOCOL.md` | Original audit and experimental protocol | Verified |
| `CHANGELOG.md` | Detailed changelog of project evolution | Verified |
| `README.md` | Main repository overview | Verified |

---

## 4. Pre-Submission Author Action Checklist

Before uploading the files to the journal portal, the author must complete the following items:

1. **Title Page Author Information** (in `Manuscript.docx` and `Cover_Letter.docx`):
   - [ ] Replace `[Author 1 full publication name]` with your full name.
   - [ ] Replace `[Author 2 if applicable]` with your co-author's name (or delete if single-authored).
   - [ ] Replace `[Department and institution or independent researcher affiliation, city, country]` with your institution.
   - [ ] Replace `[Name and email]` with your corresponding author details and ORCID.
2. **Manuscript Declarations Section** (in `Manuscript.docx`):
   - [ ] **Funding**: Specify your grant numbers or write: *"The authors declare that no funds, grants, or other support were received during the preparation of this manuscript."*
   - [ ] **Competing Interests**: Write: *"The authors have no relevant financial or non-financial interests to disclose."*
   - [ ] **Author Contributions**: Detail individual contributions (e.g., conceptualization, methodology, formal analysis, writing).
   - [ ] **Ethics & Consent**: Confirm that no human subjects or private data were involved (only the public IBM Telco benchmark).
   - [ ] **Code Availability**: Deposit the repository or `Reproducibility_Supplement.zip` to Zenodo / GitHub / OSF to obtain a DOI, and insert it in the Code Availability paragraph.
3. **Cover Letter Finalization** (in `Cover_Letter.docx`):
   - [ ] Insert the current submission date.
   - [ ] Add corresponding author contact details and signature block.
   - [ ] Remove all draft notices and bracketed instructions.
4. **Portal Upload Steps**:
   - Primary Manuscript file: `publication/Manuscript.docx`
   - Cover Letter: `publication/Cover_Letter.docx`
   - High-Resolution Figures: `publication/figures/figure1.eps` (or `.png`) and `figure2.eps` (or `.png`)
   - Supplementary Material: `publication/Reproducibility_Supplement.zip`
   - Publishing Model: Choose **Subscription** (to publish without APC fees).
