# Corrected telecom churn research report

## Assessment and contribution

This report supersedes the original submission. All numerical results below come from executed code and saved predictions. The original claims of a six-model benchmark, measured near-perfect fairness at a $23 cost, and hand-authored SHAP explanations have been withdrawn. Original artifacts remain in `original_submission/`; the evidence audit is in `audit/AUDIT_REPORT.md`.

The corrected study examines whether calibration and validation-selected economic/fairness decisions remain stable on held-out customers. Its strongest finding is a limitation: the senior equal-opportunity target failed to transfer to test data in 2 of 3 splits. The selected model differed across splits. This is an empirical benchmark contribution, not a demonstrated novel algorithm or a completed journal-ready generalization claim.

## Data and evaluation design

The supplied dataset contains 7,043 distinct customer IDs and 1,869 churn labels. Eleven whitespace cumulative-charge entries occur at zero tenure. We use conditional zero imputation plus a missingness indicator; unexpected nonnumeric values cause a failure. This convention is not a proof of unobserved billing history. ID and target columns are excluded from all predictors.

Seeds [42, 17, 2026] each split fitting, calibration, validation, and testing into approximately 45%, 15%, 20%, and 20%. For seed 42, exact sizes are 3168, 1057, 1409, and 1409, respectively. All partitions are churn-stratified and disjoint within a repeat. Repeats overlap and are not independent datasets. This benchmark was already inspected before the correction; these results are retrospective internal validation, not a prospective untouched-data claim.

There are 11 configurations per split, 33 fits total. Logistic regression, random forest, and CatBoost each use baseline, balanced class weighting, and random oversampling. Two further CatBoost fits add domain features or exclude SeniorCitizen and gender. Random oversampling duplicates fitting rows and avoids fractional categorical customers. The original claimed SMOTE/SMOTE-ENN and neural-network experiments are not part of this corrected study. Hyperparameters are fixed in source and documented in PROTOCOL.md; there is no test-driven tuning.

Standardization and one-hot encoding for logistic regression/random forest are fit only on fitting data; CatBoost handles categories natively. A regularized logistic calibrator is fitted to base-model logits/margins on separate unresampled calibration rows. We measure calibration rather than assert it is perfect. Each repeat selects the primary model by calibrated validation profit at the analytic economic threshold. The two feature ablations do not participate in that selection.

## Model results

The following are descriptive means across three test splits; they are not confidence intervals and do not establish significant superiority. Scenario profit in this table uses the fixed economic threshold 11/67. AP means average precision, not trapezoidal PR area.

| model | roc_auc | average_precision | brier | scenario_profit |
| --- | --- | --- | --- | --- |
| catboost_baseline_engineered | 0.8485 | 0.6681 | 0.1342 | 14,394.67 |
| catboost_baseline_original | 0.8472 | 0.6661 | 0.1345 | 14,179.33 |
| catboost_baseline_unaware | 0.8460 | 0.6648 | 0.1351 | 14,193.67 |
| catboost_oversampled_original | 0.8452 | 0.6630 | 0.1353 | 14,089.67 |
| catboost_weighted_original | 0.8459 | 0.6603 | 0.1353 | 14,124.67 |
| logistic_baseline_original | 0.8458 | 0.6535 | 0.1361 | 14,138.67 |
| logistic_oversampled_original | 0.8451 | 0.6495 | 0.1363 | 14,150.33 |
| logistic_weighted_original | 0.8452 | 0.6509 | 0.1364 | 14,097.33 |
| random_forest_baseline_original | 0.8466 | 0.6655 | 0.1347 | 14,145.00 |
| random_forest_oversampled_original | 0.8455 | 0.6638 | 0.1349 | 14,251.00 |
| random_forest_weighted_original | 0.8482 | 0.6670 | 0.1340 | 14,188.00 |

The full mean/min/max table and raw/calibrated metrics are available in `03_Figures_and_Tables/model_summary_across_splits.csv` and `results/model_metrics.csv`. Differences between configurations must be interpreted against retraining and test-case uncertainty. Ranking by these test means must not be confused with the validation-selected policy models.

![Calibration diagnostics](../03_Figures_and_Tables/calibration_diagnostics.png)

Calibration plots use quantile bins and are descriptive. A visually improved plot or lower Brier score does not certify calibration for every subgroup or under future distribution shift.

## Economic assumptions and fairness policy

Assume customer value=200, offer cost=10, contact cost=1 and acceptance probability=0.3, all in assumed currency units. Selected observed churners contribute 56 units and selected observed non-churners cost 11 units. Thus the analytic break-even probability is 11/67. These are simulated payoffs under a stylized campaign model, not realized profit or observed causal uplift.

For each selected model, validation chooses a global profit-maximizing threshold and a pair of senior/non-senior thresholds maximizing validation profit with absolute TPR gap at most 0.05. Tied scores are kept together and contact-none is included. The fairness objective is equal opportunity for offer allocation among observed churners. It is not a claim that all fairness definitions are simultaneously satisfied.

| seed | selected_model | global_threshold | non_senior_threshold | senior_threshold | validation_abs_gap |
| --- | --- | --- | --- | --- | --- |
| 42 | random_forest_baseline_original | 0.1566 | 0.1566 | 0.2222 | 0.0327 |
| 17 | catboost_baseline_original | 0.1852 | 0.1975 | 0.2724 | 0.0466 |
| 2026 | logistic_oversampled_original | 0.1519 | 0.1670 | 0.2293 | 0.0294 |

## Held-out policy outcomes

Profit difference below means fairness-constrained minus unconstrained validation-selected policy. A positive difference is a measured test advantage under the assumptions, not a guaranteed negative cost of fairness. The lower/upper bounds are paired 95% percentile bootstrap intervals for that difference.

| seed | unconstrained_profit | fairness_constrained_profit | profit_difference | test_abs_TPR_gap_pp | lower | upper |
| --- | --- | --- | --- | --- | --- | --- |
| 42 | 14,014.00 | 14,212.00 | 198.00 | 11.79 | 110.00 | 286.00 |
| 17 | 14,630.00 | 14,611.00 | -19.00 | 9.5320 | -365.00 | 304.00 |
| 2026 | 13,981.00 | 14,009.00 | 28.00 | 3.9748 | -252.00 | 262.00 |

The validation tolerance was exceeded in 2/3 test splits. It must not be reported as a guaranteed test-fairness constraint. Finite subgroup samples and distribution differences can make a validation solution fail to transfer. The data also do not support the original claim of a universal $23 fairness penalty. Small positive or negative profit differences do not establish practical benefit without uncertainty and economic context.

![Profit and fairness across splits](../03_Figures_and_Tables/profit_and_fairness.png)

Full policy tables include standard 0.5, analytic threshold, validation profit, equal opportunity, contact all, and contact none. Group tables cover senior status, gender, and their intersections; they derive from the actual test customer IDs. Undefined precision for zero selected cases is left missing. Selection-rate min/max ratios and max–min error gaps are provided as diagnostics, not legal compliance determinations.

## Uncertainty and sensitivity

We use 1000 paired resamples stratified jointly by churn, senior status and gender for each split. Intervals condition on the fitted model, selected policy, and empirical group counts. They do not incorporate the entire training/selection procedure or uncertain economics. Three retraining repeats show sensitivity but are insufficient for claims of independent statistical significance. No t-test over correlated folds is used.

Nine economic scenarios cross CLV in 100/200/400 with acceptance in 0.1/0.3/0.5; offer/contact costs remain fixed. In each scenario thresholds are reselected on validation data and evaluated on test data. See `economic_sensitivity.csv`. A separate empirical EMPC score integrates maximum score-threshold profit under Beta(6,14), including no contact. Test-set EMPC is labeled an oracle descriptive metric; no test-optimal threshold is used as a deployed test policy.

Feature and demographic-exclusion ablations are in `feature_and_unawareness_ablations.csv`. They compare actual fitted CatBoost models at the same analytic threshold. Added features are predictive hypotheses, not proven orthogonal transformations or causal billing mechanisms. Removing demographic columns is not assumed to remove proxies. Neither ablation warrants a causal claim.

## Genuine model explanations

We explain the unweighted original-feature CatBoost comparator on seed 42, independently of which model wins policy selection. Native CatBoost TreeSHAP supplies genuine feature contributions and the base value from training tree path statistics. The base is not the logit of test prevalence.

Sigmoid calibration is affine in logit space: calibrated logit = a × raw margin + b. Accordingly, each contribution is multiplied by a and the base is transformed by a × base + b. This preserves Shapley additivity for the same explanation game. Maximum raw-margin reconstruction error is 7.99e-15; maximum calibrated-probability reconstruction error is 6.66e-16.

![Global model attributions](../03_Figures_and_Tables/shap_global.png)

![Actual customer explanations](../03_Figures_and_Tables/shap_local_waterfalls.png)

Four real held-out customer IDs were selected by predicted-risk order without selecting their observed labels. Their feature values and contributions are exported. These plots explain predictions; they do not establish that changing a contract, payment method, or service will retain a customer. No 82% mediation claim, invented customer narrative, or untested prescription is retained.

## Research limitations and next academic steps

This remains one small, previously inspected public benchmark. There is no verified longitudinal feature cutoff, external dataset, retention experiment, actual acceptance data, or observed campaign economics. Three splits and fixed model budgets are a limited robustness study. Calibration could be compared with additional methods using development-only selection. Missing-charge sensitivity, more repeats, independent external data, and broader cost scenarios would strengthen the study.

A provisional research question is: how stable is the simulated economic cost of demographic fairness after calibration and across splits and economic assumptions? Do not claim that combining churn prediction, economics, fairness, and SHAP is itself novel. A systematic primary-paper matrix is still needed. If seeking publication, position this as a reproducible empirical robustness study and verify the contribution against the intended venue's literature. Publication readiness and acceptance are not guaranteed.

The student should be able to explain every transformation, split, threshold, and figure and trace every reported number back to saved predictions. Disclose AI assistance according to institutional/venue policy and document any correction of previously shared results.

## References and implementation sources

- Höppner et al., Profit Driven Decision Trees for Churn Prediction: https://arxiv.org/abs/1712.08101 — profit-based modeling and empirical maximum-profit definitions.
- Hardt, Price and Srebro, Equality of Opportunity in Supervised Learning: https://arxiv.org/abs/1610.02413 — group-aware post-processing framework; our deterministic threshold search is explicitly specified rather than claimed as a full replication of their algorithm.
- Chouldechova, Fair prediction with disparate impact: https://arxiv.org/abs/1703.00056 — conditional fairness incompatibilities, not proof of this dataset's mechanism.
- CatBoost TreeSHAP documentation: https://catboost.ai/docs/en/concepts/shap-values — actual contribution computation and additive output convention.
- Scikit-learn calibration documentation: https://scikit-learn.org/stable/modules/calibration.html — disjoint calibration and model-fitting data.
- Rahman, Janssens and Bogaert author repository: https://github.com/ShimantoRahman/churn-preprocessing — prior work using fairness techniques in profit-driven churn preprocessing; compare its objective carefully with demographic equal opportunity.

## Reproducibility

Run the commands in README.md. `results/manifest.json` records the data hash, executed source hash, exact configuration, Python/package versions, and completion state. Each seed folder contains split IDs, all model/calibrator objects, all validation/test predictions, frozen policy choices, and selected-policy test decisions. All tables and figures in this report are generated by `src/build_report.py`. `src/validate_results.py` reconciles exports, checks model replay, confirms split isolation, and verifies SHAP reconstruction.
